export default [
  import('./v4/index.js'),
];
